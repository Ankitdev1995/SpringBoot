package com.lcwds;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PfdGenerateApplicationTests {

	@Test
	void contextLoads() {
	}

}
