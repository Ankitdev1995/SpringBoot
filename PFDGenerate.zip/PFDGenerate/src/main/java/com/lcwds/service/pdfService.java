package com.lcwds.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfWriter;

@Service
public class pdfService {

	private Logger logger = LoggerFactory.getLogger(pdfService.class);

	public ByteArrayInputStream createPdf() {
		logger.info("create pdf started");

		String title = "Welcome to .......orangebit";
		String content = "software.....Technology";

		ByteArrayOutputStream out = new ByteArrayOutputStream();
		Document document = new Document();
		PdfWriter.getInstance(document, out);
		
		document.open();
	
		// for title
		Font titleFont =  FontFactory.getFont(FontFactory.HELVETICA_BOLD,20);	
		Paragraph titlePara = new Paragraph(title, titleFont);
		titlePara.setAlignment(Element.ALIGN_CENTER);
		document.add(titlePara);
		
		// for content
		Font paraFont = FontFactory.getFont(FontFactory.HELVETICA,18);
		Paragraph Contentparagraph = new Paragraph(content,paraFont);
		Contentparagraph.setAlignment(Element.ALIGN_MIDDLE);
		document.add(Contentparagraph);
		
		document.close();
		return new ByteArrayInputStream(out.toByteArray());
	}
}
