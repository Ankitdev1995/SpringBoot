package com.lcwds;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PfdGenerateApplication {

	public static void main(String[] args) {
		SpringApplication.run(PfdGenerateApplication.class, args);
	System.out.println("success");
	}
}
