package com.thirdParty.service;

import com.thirdParty.beans.TouristInfoBean;

public interface TouristService {
	
	public TouristInfoBean createTourist(TouristInfoBean touristDetail);
	
	
}
