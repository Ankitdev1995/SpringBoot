package com.thirdParty.serviceImpl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.thirdParty.beans.TouristInfoBean;
import com.thirdParty.service.TouristService;

@Service("touristServiceImpl")
public class TouristServiceImpl implements TouristService {
	
	Logger log = LoggerFactory.getLogger(TouristServiceImpl.class);	
	
	@Autowired
	RestTemplate restTemplate;
	
	@Override
	public TouristInfoBean createTourist(TouristInfoBean touristDetail) {
		
		log.info("start of createTourist");
		String url = "http://restapi.adequateshop.com/api/Tourist";
		HttpEntity<TouristInfoBean> touristENReq = new HttpEntity<>(touristDetail);
	
		ResponseEntity<TouristInfoBean> response = restTemplate.postForEntity(null, touristENReq, TouristInfoBean.class);
		
		log.info("end of createTourist");
		return response.getBody();
	}

}
