package com.thirdParty.beans;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class TouristInfoBean {
	
	private Long  id;
	
	@JsonProperty("tourist_name")
	private String touristName;
	
	@JsonProperty("tourist_email")
	private String touristEmail;
	
	@JsonProperty("tourist_location")
	private String  touristLocation;
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTouristName() {
		return touristName;
	}

	public void setTouristName(String touristName) {
		this.touristName = touristName;
	}

	public String getTouristEmail() {
		return touristEmail;
	}

	public void setTouristEmail(String touristEmail) {
		this.touristEmail = touristEmail;
	}

	public String getTouristLocation() {
		return touristLocation;
	}

	public void setTouristLocation(String touristLocation) {
		this.touristLocation = touristLocation;
	}
	
	

}
