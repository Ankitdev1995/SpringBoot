package com.thirdParty.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.thirdParty.beans.TouristInfoBean;
import com.thirdParty.serviceImpl.TouristServiceImpl;

@RestController
public class TouristController {

	@Autowired
	TouristServiceImpl touristServiceImpl;
	
	Logger log = LoggerFactory.getLogger(TouristController.class);
	
	@PostMapping(value="/createTouristInfo")
	public TouristInfoBean createTouristInfo(@RequestBody TouristInfoBean touristInfo) {

		log.info("Start of createTouristInfo...");
		
		
		TouristInfoBean infoBean = new TouristInfoBean(); 
		infoBean = touristServiceImpl.createTourist(touristInfo);
		log.info("End of createTouristInfo...");
		return infoBean;
		
	}
	
}
