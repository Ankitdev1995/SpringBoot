package com.stackInstance.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.stackInstance.entity.User;

public interface UserRepository extends JpaRepository<User, Integer> {

	public List<User> findByCity(String city);

	public List<User> findByNameOrCity(String name, String city);
	
	// jpql(java persistance query language)

	@Query("select u from User u")
	public List<User> getAllUsersJPQL();
	
	@Query("select u from User u where u.city=:c")
	public List<User> getUserByCityUsingJPQL(@Param("c") String city);
	
	// for and
	// "select u from User u where u.city=:c and u.name=:n"
	
	@Query("select u from User u where u.city=:c or u.name=:n")
	public List<User> findByNamesOrCities(@Param("c") String city, @Param("n") String name);
	
	// native queries

	@Query(value ="select * from User", nativeQuery = true)
	public List<User> getAllUsersUsingNative();
	
	
}
