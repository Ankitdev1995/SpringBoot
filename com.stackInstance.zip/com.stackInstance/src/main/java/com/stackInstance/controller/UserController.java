package com.stackInstance.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stackInstance.entity.User;
import com.stackInstance.service.UserService;

@RestController
@RequestMapping("/stackInstance")
public class UserController {

	@Autowired
	private UserService UserService;

	@PostMapping("/addUser")
	public String addUser(@RequestBody User user) {
		UserService.saveUser(user);
		return "saved user succesfullly";
	}

	@GetMapping("/getAllUsers")
	public List<User> getAllUsers(){
		return UserService.getAllUsers();
	}

	@GetMapping("/getUserById/{}")
	public Optional<User> getUserById(@PathVariable int id){
		Optional<User> listById = UserService.getUserById(id);
		return listById;
	}
	@GetMapping("/getUserByCityName/{city}")
	public List<User> getUserByCityName(@PathVariable String city){
		return UserService.getUserByCity(city);
	}
	
	@GetMapping("getUserByNameOrCity/{name}/{city}")
	public List<User> findByNameOrCity(@PathVariable String name, @PathVariable String city){
		return UserService.findByNameOrCity(name, city);
	}
	
	// jpql queries
	
		@GetMapping("/getAllUserJPQL")
		public List<User> getAllUsersUsingJPQL(){
			 List<User> users =  UserService.getAllUsersUsingJPQL();
			 return users;
		}
		
		@GetMapping("/getUserByCityUsingJPQL/{city}")
		public List<User> getUserByCityUsingJPQL(@PathVariable String city){
			return UserService.getUserByCityUsingJPQL(city);	
		}
		@GetMapping("/findByNameOrCityJPQL/{city}/{name}")
		public List<User> findBynamesOrCity(@PathVariable String city, @PathVariable String name){
			return UserService.findByNameOrCity(city, name);
		}
		@GetMapping("/getAllUsersUsingNative")
		public List<User> getAllUsersUsingNative(){
			return UserService.getAllUsersUsingNative();
		}
		
}
