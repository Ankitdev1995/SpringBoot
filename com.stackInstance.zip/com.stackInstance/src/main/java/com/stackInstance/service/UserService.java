package com.stackInstance.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackInstance.entity.User;
import com.stackInstance.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	public void saveUser(User user) {
		userRepository.save(user);
	}

	public List<User> getAllUsers(){

		List<User> listUser = userRepository.findAll();
		return listUser;
	}

	public Optional<User> getUserById(int id){
		return userRepository.findById(id);
	}

	public List<User> getUserByCity(String city){
		List<User> listUsers =  userRepository.findByCity(city);
		return listUsers;
	}

	public List<User> findByNameOrCity(String name, String city){
		List<User> listUsers = userRepository.findByNameOrCity(name, city);
		return listUsers;
	}
	public List<User> getAllUsersUsingJPQL(){
		return userRepository.getAllUsersJPQL();
	}
	
	public List<User> getUserByCityUsingJPQL(String city){
		return userRepository.getUserByCityUsingJPQL(city);
	}
	
	public List<User> findBynamesOrCity(String city, String name){
		return userRepository.findByNamesOrCities(city, name);
	}
	// native query
	public List<User> getAllUsersUsingNative(){
		return userRepository.getAllUsersUsingNative();
	}
	
	public List<User> getUSersByCityName(){
		return null;
	}
}