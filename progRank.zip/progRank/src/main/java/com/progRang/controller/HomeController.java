package com.progRang.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {
	// default authentication filter is BasicAuthenticationFilter
	
	@RequestMapping("/hello")
	public String sayhi() {
		return "Welcome";
	}
}
