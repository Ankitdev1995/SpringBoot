package com.progRang;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProgRankApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProgRankApplication.class, args);
		System.out.println("Success");
	}
}
