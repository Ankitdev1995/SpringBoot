package com.progRang;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgRankApplicationTests {

	@Test
	void contextLoads() {
	}

}
