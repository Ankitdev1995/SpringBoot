package com.programmingtechie.service;

import org.springframework.stereotype.Service;

import com.programmingtechie.dto.ProductRequest;
import com.programmingtechie.model.Product;

@Service
public class ProductService {
public void createProduct(ProductRequest productRequest) {
//	Product product = Product.builder()
//			.name(productRequest.getName())
//			.description(productRequest.getDescription())
//			.price(productRequest.getPrice())
//			.build();
}
}
