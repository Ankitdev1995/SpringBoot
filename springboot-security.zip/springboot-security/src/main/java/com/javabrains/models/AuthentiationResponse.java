package com.javabrains.models;

public class AuthentiationResponse {
	
	private final String jwt;
	
	public AuthentiationResponse(String jwt) {
		this.jwt = jwt;
	}
	public String getJwt() {
		return jwt;
	}
}
