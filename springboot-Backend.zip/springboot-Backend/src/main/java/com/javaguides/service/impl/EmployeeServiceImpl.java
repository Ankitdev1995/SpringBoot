package com.javaguides.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javaguides.entities.Employee;
import com.javaguides.exception.ResourceNotFoundException;
import com.javaguides.repositories.EmployeeRepository;
import com.javaguides.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	
	public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
		super();
		this.employeeRepository = employeeRepository;
	}

	@Override
	public Employee saveEmployee(Employee employee) {
	return employeeRepository.save(employee);
	
	}

	@Override
	public List<Employee> getAllEmployee() {
		return  employeeRepository.findAll();
	}

	@Override
	public Employee getEmployeeById(long id) {
		Optional<Employee> employee = employeeRepository.findById(id);
		if(employee.isPresent()) {
			return employee.get();
		}else {
		throw  new ResourceNotFoundException("Employee", "id", id);
		}
	//	return employeeRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("employee", "id", id));		
	}

	@Override
	public Employee updateEmployee(Employee employee, long id) {
		// first we need to check whether employee with given id is exist in DB or not 
		Employee existingEmp = employeeRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("Employee", "id", id));
		existingEmp.setFirstname(employee.getFirstname());
		existingEmp.setLastname(employee.getLastname());
		existingEmp.setEmail(employee.getEmail());
		
		// save existing employee to DB
		employeeRepository.save(existingEmp);
		
		return existingEmp;
	}

	@Override
	public void deleteEmployee(long id) {
		// check whether the employee exist in DB or Not
		
		employeeRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("Employee", "id", id));
		employeeRepository.deleteById(id);
	}
}
