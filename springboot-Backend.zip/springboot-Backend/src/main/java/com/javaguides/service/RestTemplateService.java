package com.javaguides.service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.javaguides.entities.Employee;

@Service
public class RestTemplateService {

	RestTemplate restTemplate =  new RestTemplate();
	private static final String GET_ALL_EMPLOYEE_URL = "http://localhost:8080/api/getEmployee";
	private static final String CREATE_EMPLOYEE_URL = "http://localhost:8080/api/addEmployee";
	private static final String GET_EMPLOYEE_BY_ID = "http://localhost:8080/api/{id}";
	private static final String UPDATE_EMPLOYEE_URL = "http://localhost:8080/api/{id}";
	// method to get all employee
	public ResponseEntity<String> allEmployee(){
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<>("parameters", headers);
		ResponseEntity<String> response = restTemplate.exchange(GET_ALL_EMPLOYEE_URL, HttpMethod.GET, entity, String.class);
		return response;
	}

	public ResponseEntity<Employee> createEmployee(Employee employee){
		return restTemplate.postForEntity(CREATE_EMPLOYEE_URL, employee, Employee.class);
	}
	
	public Employee getEmployeeById(long id ){
		Map<String,Long> param = new HashMap<String,Long>();
		param.put("id", id);	
		return restTemplate.getForObject(GET_EMPLOYEE_BY_ID,Employee.class,param);
	}
	
	public void updateEmployee(Employee employee) {
		
	 restTemplate.put(UPDATE_EMPLOYEE_URL, employee);
	 
	}	
}
