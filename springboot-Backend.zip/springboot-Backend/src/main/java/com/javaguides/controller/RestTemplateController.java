package com.javaguides.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.javaguides.entities.Employee;
import com.javaguides.service.RestTemplateService;

@RestController
@RequestMapping("/RestTemplate")
public class RestTemplateController {

	@Autowired
	RestTemplateService restTemplateService;

	@GetMapping("/getAllEmployee")
	public ResponseEntity<String> getAllEmployee(){
		return restTemplateService.allEmployee();
	}

	@PostMapping("/addEmployee")
	public ResponseEntity<Employee> addEmployee(@RequestBody Employee employee){
		return restTemplateService.createEmployee(employee);
	}
	@GetMapping("getEmployee/{id}")
	public Employee getEmployeeById(@PathVariable long id){
		return restTemplateService.getEmployeeById(id);
	}
	@PutMapping("updateEmp")
	public void updateEmployee(@RequestBody Employee employee) {
		 restTemplateService.updateEmployee(employee);
	}
}
