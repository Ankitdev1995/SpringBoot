package com.javaguides.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.javaguides.entities.Employee;
import com.javaguides.service.EmployeeService;

@RestController
@RequestMapping("/api")
public class EmployeeControllers {
	
	@Autowired
	private EmployeeService employeeService;
	
	public EmployeeControllers(EmployeeService employeeService) {
		super();
		this.employeeService = employeeService;
	}
	
	@PostMapping("/addEmployee")
	public ResponseEntity<Employee> saveEmployee(@RequestBody Employee Employee){
		Employee emp = employeeService.saveEmployee(Employee);
		return new ResponseEntity<Employee>(emp, HttpStatus.CREATED);
	}
	
	@GetMapping("/getEmployee")
	public ResponseEntity<List<Employee>> getAllEmployee(){
	List<Employee> listemployee = employeeService.getAllEmployee();
		return new ResponseEntity<List<Employee>>(listemployee,HttpStatus.OK);
		
	}
	@GetMapping("{id}")
	public ResponseEntity<Employee> employeeById(@PathVariable("id") long id){
		Employee emp = employeeService.getEmployeeById(id);
		return new ResponseEntity<Employee>(emp, HttpStatus.OK);	
	}
	@PutMapping("/{id}")
	public ResponseEntity<Employee> updateEmployee(@PathVariable("id") long id, @RequestBody Employee employee){
		Employee e = employeeService.updateEmployee(employee, id);	
		return new ResponseEntity<Employee>(e, HttpStatus.OK);
		
	}
	@DeleteMapping("{id}")
	public ResponseEntity<String> deleteEmployee(@PathVariable("id") long id){
	
		employeeService.deleteEmployee(id);
		return new  ResponseEntity<String>("DeleteEmp",HttpStatus.OK);
	}
}
