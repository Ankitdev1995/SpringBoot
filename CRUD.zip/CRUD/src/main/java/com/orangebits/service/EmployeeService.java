package com.orangebits.service;

import java.util.List;

import com.orangebits.entity.Employee;


public interface EmployeeService {

	public Employee SaveEmployee(Employee employee);

	public List<Employee> getAllEmployee();

	Employee getEmployeeById(long id);

	public Employee updateEmployee(Employee employee ,long id);

	public void deleteEmployee(long id);

}
