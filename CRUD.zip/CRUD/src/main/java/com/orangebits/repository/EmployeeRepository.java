package com.orangebits.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.orangebits.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

}
