package com.orangebits.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.orangebits.entity.Employee;
import com.orangebits.service.EmployeeService;

@RestController
@RequestMapping("/api")
public class EmployeeController {
	@Autowired
	private EmployeeService employeeService; 
	
	@PostMapping("/saveEmp")
	ResponseEntity<Employee> saveEmployee(@RequestBody Employee employee){
		Employee Saveemp = employeeService.SaveEmployee(employee);
		return new ResponseEntity<Employee>(Saveemp, HttpStatus.CREATED);	
	}
	@GetMapping("/getEmp")
	ResponseEntity<List<Employee>> getAllEmployee(){
		List<Employee> getAllEmp =  employeeService.getAllEmployee();
		return new ResponseEntity<List<Employee>>(getAllEmp, HttpStatus.OK);
	}
	@PutMapping("/{id}")
	ResponseEntity<Employee> updateEmployee(@PathVariable("id") long id , @RequestBody Employee employee){
		 Employee emp = employeeService.updateEmployee(employee, id);
		return new ResponseEntity<Employee>(emp, HttpStatus.OK);
	}
	@DeleteMapping("/{id}")
	ResponseEntity<String> deleteEmployee(@PathVariable long id ){
		employeeService.deleteEmployee(id);
	return new ResponseEntity<String> ("deleEmp",HttpStatus.OK);
	}
	
}
