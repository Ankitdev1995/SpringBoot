package com.orangebits.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.orangebits.entity.Employee;
import com.orangebits.exception.ResourceNotFoundException;
import com.orangebits.repository.EmployeeRepository;
import com.orangebits.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	EmployeeRepository employeeRepository;

	@Override
	public Employee SaveEmployee(Employee employee) {
		return	employeeRepository.save(employee);

	}

	@Override
	public List<Employee> getAllEmployee() {
		return employeeRepository.findAll();

	}

	@Override
	public Employee getEmployeeById(long id) {
		Optional<Employee> employee = employeeRepository.findById(id);
		if(employee.isPresent()) {
			return employee.get();
		}else {
			throw new ResourceNotFoundException("employee","id",id);
		}

	}

	@Override
	public Employee updateEmployee(Employee employee, long id) {
		Employee existingEmp = 	employeeRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("employee", "id", id));

		existingEmp.setFirstName(employee.getFirstName());
		existingEmp.setLastName(employee.getLastName());
		existingEmp.setEmail(employee.getEmail());
		employeeRepository.save(existingEmp);
		return existingEmp;
	}

	@Override
	public void deleteEmployee(long id) {
		employeeRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("employee", "id", id));
		employeeRepository.deleteById(id);
	}

}
