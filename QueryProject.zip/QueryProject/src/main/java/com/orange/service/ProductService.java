package com.orange.service;

import com.orange.entity.Product;

public interface ProductService {
	public Product saveProduct(Product product); 

}
