package com.orange.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.orange.entity.Product;
import com.orange.repository.ProductRepositoy;
import com.orange.service.ProductService;
@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepositoy productRepository;
	
	@Override
	public Product saveProduct(Product product) {
	return	productRepository.save(product);
	
	}
	

}
