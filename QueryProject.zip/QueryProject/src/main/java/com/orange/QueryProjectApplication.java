package com.orange;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QueryProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(QueryProjectApplication.class, args);
	System.out.println("success");
	}

}
