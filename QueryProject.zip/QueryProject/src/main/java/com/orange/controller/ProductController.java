package com.orange.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.orange.entity.Product;
import com.orange.service.ProductService;

@RestController
@RequestMapping("/api")
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	@PostMapping("/save")
	ResponseEntity<Product> saveProduct(@RequestBody Product product){
		Product saveProduct  = productService.saveProduct(product);
		return new ResponseEntity<Product>(saveProduct, HttpStatus.CREATED);
	}
}
