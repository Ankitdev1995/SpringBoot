package com.orange.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.orange.entity.Product;

@Repository
public interface ProductRepositoy extends JpaRepository<Product, Integer> {

	@Query(value = "SELECT * FROM product WHERE price < : maxPrice", nativeQuery = true,
			countQuery = "SELECT * FROM products WHERE price < :maxPrice")
	public List<Product> getProductsWithMaxPrice(Integer maxPrice);
	
	@Query(value = "UPDATE product SET price += :amount",nativeQuery = true)
	public void updatePrice(Integer amount);
}
