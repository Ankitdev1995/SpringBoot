package com.orange;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;

import com.orange.entity.Product;
import com.orange.repository.ProductRepositoy;

@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Rollback(false)
@SpringBootTest
class QueryProjectApplicationTests {

	@Test
	void contextLoads() {
	}
	
	@Autowired
	private ProductRepositoy repo;

	@Test
	public void testListAll() {
		List<Product> listProducts = repo.findAll();
		listProducts.forEach(System.out::println);
	}
	@Test
	public void testGetProductMaxPrice() {
		Integer maxPrice = 1000;
	List<Product> listProducts = repo.getProductsWithMaxPrice(maxPrice);
	listProducts.forEach(System.out::println);
	}

}
