package com.mapping.entity;

import org.springframework.data.annotation.Id;

public class Book {
	
	@Id
	private Integer bookId;
	private String bname;
	
}
