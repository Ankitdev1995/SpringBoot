package com.mapping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataJpaMappingApplicationTests {

	@Test
	void contextLoads() {
	}

}
