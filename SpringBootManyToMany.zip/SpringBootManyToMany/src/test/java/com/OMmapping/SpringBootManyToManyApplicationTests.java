package com.OMmapping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootManyToManyApplicationTests {

	@Test
	void contextLoads() {
	}

}
