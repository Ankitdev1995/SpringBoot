package com.MMmapping.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "bktbl")
public class Book {
	
	@Id
	private Integer bid;
	private String bname;
	
	public Book() {
		
	}

	public Book(Integer bid, String bname) {
		super();
		this.bid = bid;
		this.bname = bname;
	}
	
	
}
