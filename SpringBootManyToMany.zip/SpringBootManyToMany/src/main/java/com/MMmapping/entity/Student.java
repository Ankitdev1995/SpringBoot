package com.MMmapping.entity;

import java.util.Set;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "stdtbl")
public class Student {
	
	@Id
	private Integer stdId;
	private String sname;
		
	  @ManyToMany()
	    @JoinTable(name = "stbktbl",
	            joinColumns = @JoinColumn(name = "sidFK"),
	            inverseJoinColumns = @JoinColumn(name = "bidFK"))
	    private Set<Book> books;

	public Student(Integer stdId, String sname, Set<Book> books) {
		super();
		this.stdId = stdId;
		this.sname = sname;
		this.books = books;
	}
	
	  
}
