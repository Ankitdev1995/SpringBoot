package com.MMmapping.runner;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.MMmapping.entity.Book;
import com.MMmapping.entity.Student;
import com.MMmapping.repository.BookRepository;
import com.MMmapping.repository.StudentRepository;

@Component
public class TestRunner implements CommandLineRunner{

	@Autowired
	private BookRepository bookRepository;
	
	@Autowired
	private StudentRepository studentrepository;
	
	@Override
	public void run(String... args) throws Exception {
	
	Book book1 = new Book(50, "DS");
	Book book2 = new Book(60, "SB");
	Book book3 = new Book(70, "HB");
	
	bookRepository.save(book1);
	bookRepository.save(book2);
	bookRepository.save(book3);
	
	Set<Book> s1 = Set.of(book1,book3);
	Set<Book> s2 = Set.of(book2,book3);
	
	Student student1 = new Student(101, "SAM", s1);
	Student student2 = new Student(102, "JHON", s2);
	
	studentrepository.save(student1);
	studentrepository.save(student2);
		
	}
}
