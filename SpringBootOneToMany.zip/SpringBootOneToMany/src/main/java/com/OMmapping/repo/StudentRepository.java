package com.OMmapping.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.OMmapping.entity.Student;

public interface StudentRepository extends JpaRepository<Student, Integer> {

}
