package com.OMmapping.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.OMmapping.entity.Book;

public interface BookRepository extends JpaRepository<Book, Integer> {

}
