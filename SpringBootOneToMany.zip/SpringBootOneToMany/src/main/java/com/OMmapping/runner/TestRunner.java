package com.OMmapping.runner;


import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.OMmapping.entity.Book;
import com.OMmapping.entity.Student;
import com.OMmapping.repo.BookRepository;
import com.OMmapping.repo.StudentRepository;

@Component
public class TestRunner implements CommandLineRunner{

	@Autowired
	private BookRepository bookrepository;

	@Autowired
	private StudentRepository studentRepository;
	
	
	@Override
	public void run(String... args) throws Exception {
		
		Book book1 = new Book(50, "DS");
		Book book2 = new Book(60, "SB");
			
		bookrepository.save(book1);
		bookrepository.save(book2);
		
		Set<Book> s1 = Set.of(book1, book2);
		
		Student student1 = new Student(101, "SAM",s1);
		
		studentRepository.save(student1);
		
		
	}

}
