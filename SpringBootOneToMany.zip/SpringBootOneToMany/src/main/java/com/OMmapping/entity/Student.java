package com.OMmapping.entity;

import java.util.Set;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name ="stdtbl" )
public class Student {

	@Id
	private Integer Sid;
	private String Sname;

	@OneToMany
	@JoinColumn(name = "sidfk")
	private Set<Book> bobs;

	public Student() {

	}

	public Student(Integer sid, String sname, Set<Book> bobs) {
		super();
		Sid = sid;
		Sname = sname;
		this.bobs = bobs;
	}


}
