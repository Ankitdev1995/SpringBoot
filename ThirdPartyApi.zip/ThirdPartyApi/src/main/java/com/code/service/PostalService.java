package com.code.service;

import com.code.output.PostOfficeResponseBean;

public interface PostalService {
	
	public PostOfficeResponseBean fetchPostOfficeDetailsByCity(String city);
}
