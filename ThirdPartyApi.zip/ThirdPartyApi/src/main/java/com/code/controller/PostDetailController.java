package com.code.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.code.output.PostOfficeResponseBean;
import com.code.service.PostalService;

@RestController
@RequestMapping("/postal")
public class PostDetailController {
	
	@Autowired
	PostalService postalServiceImpl;

	@RequestMapping(value="/bycity", method = RequestMethod.GET, consumes = MediaType.ALL_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public PostOfficeResponseBean getPostalByCity(@RequestParam String city) {
	
		PostOfficeResponseBean postalResponse;
		
		postalResponse = postalServiceImpl.fetchPostOfficeDetailsByCity(city);
		
		return postalResponse;
		
	}
}
