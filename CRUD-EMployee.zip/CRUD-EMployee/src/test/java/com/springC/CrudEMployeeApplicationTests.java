package com.springC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudEMployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
