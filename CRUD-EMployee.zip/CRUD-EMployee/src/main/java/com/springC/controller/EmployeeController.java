package com.springC.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.springC.entity.Employee;
import com.springC.repository.EMployeeRepo;

@RestController
@RequestMapping("/api")
public class EmployeeController {

	@Autowired
	EMployeeRepo empRepo;

	@PostMapping("/employee")
	public String saveEmployee(@RequestBody Employee employee){
		empRepo.save(employee);
		return "Employee Created in database";
	}
	@GetMapping("/getEmployee")
	public ResponseEntity<List<Employee>> getAllEmployee(){
		List<Employee> emplist = new ArrayList<Employee>();
		empRepo.findAll().forEach(emplist::add);
		System.out.println(emplist);
		return new ResponseEntity<List<Employee>>(emplist,HttpStatus.OK);
	}
	@GetMapping("/getEmp/{empid}")
	ResponseEntity<Employee> getEmployeeById(@PathVariable long empid){
		Optional<Employee> emp = empRepo.findById(empid)	;
		if(emp.isPresent()) {
			return new ResponseEntity<Employee>(emp.get(),HttpStatus.FOUND);
		}else {
			return new	ResponseEntity<Employee>(HttpStatus.NOT_FOUND);
		}
	}
	@PutMapping("/employee/{empid}")
	public String updateEmployeeById(@PathVariable long empid, @RequestBody Employee employee){
		Optional<Employee> emp =  empRepo.findById(empid);

		if(emp.isPresent()) {
			Employee exsistingEMp = emp.get();
			exsistingEMp.setEmp_name(employee.getEmp_name());
			exsistingEMp.setEmp_age(employee.getEmp_age());
			exsistingEMp.setEmp_city(employee.getEmp_city());
			exsistingEMp.setEmp_salary(employee.getEmp_salary());

			empRepo.save(exsistingEMp);
			return "employee details against id "+empid;
		}else {
			return "Employee Details does not exists : "+ empid;

		}
	}
	@DeleteMapping("/employee/{empid}")
	public String deleteEmployeeByEmpId(@PathVariable long empid ) {
		empRepo.deleteById(empid);
		return "Employee Deleted Successfully";
	}

	@DeleteMapping("employee")
	public String deleteAllEmployee() {
		empRepo.deleteAll();
		return "Employee deleted successfully...";
	}
	@GetMapping("/employee/emp_city")
	public ResponseEntity<Employee> findEmpByCity(@RequestParam("emp_city") String emp_city) {
		Employee emp = empRepo.findEmployeeByEmpCity(emp_city);
		return new ResponseEntity<Employee>(emp, HttpStatus.FOUND);
	}
	@GetMapping("/employee/employeeGreaterThan")
	public ResponseEntity<List<Employee>> findByEmpageGreaterThan(@RequestParam("emp_age") int emp_age ){
		Optional<List<Employee>> emp =	empRepo.findByEmpageGreaterThan(emp_age);
		return new ResponseEntity<List<Employee>>(emp.get(), HttpStatus.FOUND);
	}
}
