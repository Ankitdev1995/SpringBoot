 package com.springC.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;


import com.springC.entity.Employee;

public interface EMployeeRepo extends JpaRepository<Employee, Long>{
	
	 Employee findEmployeeByEmpCity(String emp_city);
	 
	 Optional<List<Employee>> findByEmpageGreaterThan(int emp_age);
}
