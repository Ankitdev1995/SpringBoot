package com.springC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudEMployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudEMployeeApplication.class, args);
	System.out.println("success");
	}

}
