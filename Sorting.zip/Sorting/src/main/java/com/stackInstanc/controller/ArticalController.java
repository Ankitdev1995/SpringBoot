package com.stackInstanc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stackInstanc.model.Article;
import com.stackInstanc.service.ArticalService;

@RestController
@RequestMapping("/stack")
public class ArticalController {

	@Autowired
	private ArticalService articleService;

	@GetMapping("/allArticles")
	public List<Article> getArticle(){
		return articleService.findAllArticle();
	}

	@GetMapping("/{field}")
	public List<Article> getArticleWithSort(@PathVariable String field){
		List<Article> allArticles = articleService.findArticlewithSorting(field);
		return allArticles;
	}
}
