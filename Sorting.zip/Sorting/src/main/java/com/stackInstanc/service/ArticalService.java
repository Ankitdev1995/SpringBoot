package com.stackInstanc.service;

import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import com.stackInstanc.model.Article;
import com.stackInstanc.repository.ArticleRepository;

@Service
public class ArticalService {

	@Autowired
	private ArticleRepository articleRepository;

	@PostConstruct
	public void initLoadToDB() {
		List<Article> articles = IntStream.rangeClosed(1, 100)
				.mapToObj(i->new Article("Article"+i, new Random()
						.nextInt(100), new Random()
						.nextInt(20000)))
				.collect(Collectors.toList());
				articleRepository.saveAll(articles);
	}
	
	public List<Article> findAllArticle(){
		 List<Article> listArt = articleRepository.findAll();
		 return listArt;
	}
	public List<Article> findArticlewithSorting(String field){
		return articleRepository.findAll(Sort.by(Sort.Direction.ASC,field));
	}
}
