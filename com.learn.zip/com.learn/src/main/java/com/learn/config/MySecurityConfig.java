package com.learn.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
@EnableWebSecurity
public class MySecurityConfig extends WebSecurityConfigurerAdapter {

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		http
			.csrf()
			.disable()
			.authorizeRequests()
			.antMatchers("/signin").permitAll()
		    .antMatchers("/public/**").hasRole("NORMAL")
		    .antMatchers("/users/**").hasRole("ADMIN")
			.anyRequest()
			.authenticated()
			.and()
			.httpBasic()
			.and()
			.formLogin()
			.loginPage("/signin");
			
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.inMemoryAuthentication().withUser("jhon").password(this.passwordEncoder().encode("durgesh")).roles("NORMAL");
		auth.inMemoryAuthentication().withUser("roshni").password(this.passwordEncoder().encode("abc")).roles("ADMIN");
	}

	/*
	 * In basic authentication we can't logout
	 */
	
	/*
	 * ROLE means high level overview -> normal, :read
	 * Authority- permission -> 
	 * Admin is the role and read, write , update is the authority
	 */
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder(10);
		 
	}
}
