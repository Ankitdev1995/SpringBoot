package com.stackInstance.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Entity
public class User {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int uId ;
	// username should not be null or empty
	// username should have atleast 4 character
	@NotEmpty
	@Size(min = 4 , message = "username must be atleast of 4 chatarcter")
	private String uName;
	
	private String uCity;
	
	// email should not be empty or null
	// email should be in valid format
	@NotEmpty
	@Email
	private String uEmail;
	
	public User() {
		
	}
	public User(int uId, String uName, String uCity, String uEmail) {
		super();
		this.uId = uId;
		this.uName = uName;
		this.uCity = uCity;
		this.uEmail = uEmail;
	}
	public int getuId() {
		return uId;
	}

	public void setuId(int uId) {
		this.uId = uId;
	}

	public String getuName() {
		return uName;
	}

	public void setuName(String uName) {
		this.uName = uName;
	}

	public String getuCity() {
		return uCity;
	}

	public void setuCity(String uCity) {
		this.uCity = uCity;
	}

	public String getuEmail() {
		return uEmail;
	}

	public void setuEmail(String uEmail) {
		this.uEmail = uEmail;
	}
	@Override
	public String toString() {
		return "User [uId=" + uId + ", uName=" + uName + ", uCity=" + uCity + ", uEmail=" + uEmail + "]";
	}
	
}
