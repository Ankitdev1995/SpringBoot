package com.stackInstance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@SpringBootApplication
@EnableAsync
public class ValidationProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ValidationProjectApplication.class, args);
		System.out.println("success");
	}

	// thread pool task Executer class
	@Bean("asyncExecution")
	public TaskExecutor getAsyncExecututor() {
		ThreadPoolTaskExecutor executer = new ThreadPoolTaskExecutor();
		executer.setCorePoolSize(20);
		executer.setMaxPoolSize(1000);
		executer.setWaitForTasksToCompleteOnShutdown(true);
		executer.setThreadNamePrefix("Async-");
		return executer;
	} 
}
