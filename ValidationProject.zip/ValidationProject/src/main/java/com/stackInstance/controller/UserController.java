package com.stackInstance.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stackInstance.entity.User;
import com.stackInstance.service.UserService;

@RestController
@RequestMapping("/stackIn")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@PostMapping("/save")
	ResponseEntity<User> saveUser (@Valid @RequestBody User user){
		User Createusers = userService.saveUser(user);
		userService.getUser();
		return new ResponseEntity<User>(Createusers, HttpStatus.CREATED);
	}
	
}
