package com.stackInstance.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.stackInstance.entity.User;
import com.stackInstance.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	public User saveUser(User user) {
		userRepository.save(user);
		return user;
	}
	@Async("asyncExecution")
	public void getUser() {
		try {
			System.out.println("sleep method started");
			Thread.sleep(10000);
			System.out.println("sleep method Ended");
			List<User> response = userRepository.findAll();
			response.forEach(user->{
				System.out.println("response data "+ user.toString());
			});
		}catch(InterruptedException e){
			e.printStackTrace();			
		}
	}
}
