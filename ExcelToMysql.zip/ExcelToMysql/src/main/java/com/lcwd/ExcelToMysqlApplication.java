package com.lcwd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExcelToMysqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExcelToMysqlApplication.class, args);
	}

}
