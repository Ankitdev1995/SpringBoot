package com.lcwd.service;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.lcwd.entities.Product;
import com.lcwd.helper.ProductHelper;
import com.lcwd.repository.ProductRepository;

@Service
public class ProductService {
	
	@Autowired
	private ProductRepository productRepo;
	
	public void save(MultipartFile file) throws IOException {
		
			try {
				List<Product> products = ProductHelper.convertExcelToListOfProduct(file.getInputStream());
				this.productRepo.saveAll(products);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	public List<Product> getAllPorduct(){
	
		return this.productRepo.findAll();
	}
}
