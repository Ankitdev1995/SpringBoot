package com.mapping.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.mapping.entity.Book;
import com.mapping.entity.Student;
import com.mapping.repo.BookRepository;
import com.mapping.repo.StudentRepository;

@Component
public class TestRunner implements CommandLineRunner {
	
	@Autowired
	private BookRepository bookRepository;
	
	@Autowired
	private StudentRepository studentRepository;
	
	@Override
	public void run(String... args) throws Exception {
		
		// create the book book object
		
		Book bk1 = new Book(101, "DS");
		
		Book bk2 = new Book(102, "SB");
		
		bookRepository.save(bk1);
		bookRepository.save(bk2);
		
		Student st1 = new Student(50, "SAM", bk1);
		
		Student st2 = new Student(60, "JHON", bk1);
		
		Student st3 = new Student(70, "prem", bk2);
		
		Student st4 = new Student(80, "rahul", bk2);
		
		studentRepository.save(st1);
		studentRepository.save(st2);
		studentRepository.save(st3);
		studentRepository.save(st4);
		
		
		
	}

}
