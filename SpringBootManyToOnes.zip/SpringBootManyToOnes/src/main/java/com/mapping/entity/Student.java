package com.mapping.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "stdtbl")
public class Student {
	
	@Id
	private Integer sid;
	
	private String name;
	
	@ManyToOne
	@JoinColumn(name = "bidfk")
	private Book book;
	
	public Student() {
		// TODO Auto-generated constructor stub
	}

	public Student(Integer sid, String name, Book book) {
		super();
		this.sid = sid;
		this.name = name;
		this.book = book;
	}
	
	

}
