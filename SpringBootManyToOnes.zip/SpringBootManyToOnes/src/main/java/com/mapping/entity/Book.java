package com.mapping.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "bktab")
public class Book {
	
	@Id
	private Integer BId;
	private String name;
	
	public Book() {
		
	}
	
	public Book(Integer bId, String name) {
		super();
		BId = bId;
		this.name = name;
	}
	
	

}
