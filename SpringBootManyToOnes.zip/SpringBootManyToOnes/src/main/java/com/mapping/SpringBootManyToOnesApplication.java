package com.mapping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootManyToOnesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootManyToOnesApplication.class, args);
	}

}
