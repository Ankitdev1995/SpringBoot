package com.mapping.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mapping.entity.Book;

public interface BookRepository extends JpaRepository<Book, Integer>{

}
