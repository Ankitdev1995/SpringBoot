package com.stackInst.entity;

public class Employee {

}
