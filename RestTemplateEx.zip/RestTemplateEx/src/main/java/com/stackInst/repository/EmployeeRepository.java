package com.stackInst.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stackInst.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer>{

}
