package com.stackInst;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestTemplateExApplicationTests {

	@Test
	void contextLoads() {
	}

}
